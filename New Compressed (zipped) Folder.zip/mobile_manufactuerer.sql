SELECT * FROM DIM_MANUFACTURER
SELECT  * FROM DIM_MODEL
SELECT  * FROM DIM_CUSTOMER
SELECT  * FROM DIM_LOCATION

SELECT  * FROM DIM_DATE
SELECT  * FROM FACT_TRANSACTIONS

--SQL Advance Case Study


--Q1--BEGIN 
	select B.state as states from FACT_TRANSACTIONS as A
	left join DIM_LOCATION as B 
	on A.IDLocation  = B.IDLocation
	where A.Date >= '2005'
	group by B.State


--Q1--END

--Q2--BEGIN.What state in the US is buying the most 'Samsung' cell phones?
	select B.State ,sum(totalprice)  as state_sale_total from FACT_TRANSACTIONS as A   
	inner join DIM_LOCATION as B 
	on A.IDLocation = B.IDLocation
	where B.Country = 'US' And A.IDModel in
	(select D.IdModel from DIM_MANUFACTURER as C
	inner join DIM_MODEL as D 
	On c.IDManufacturer = D.IDManufacturer
	where C.Manufacturer_Name = 'SAMSUNG'
	group by D. IDModel)
	group by B.State
	order by state_sale_total Desc

--Q2--END

--Q3--BEGIN .Show the number of transactions for each model per zip code per state.     
	select c.model_name, B.zipcode,b.state,COUNT(A.idmodel) as tran_no
	from FACT_TRANSACTIONS as A
	inner join DIM_LOCATION As B 
	On A.IDLocation = B.IDLocation
	inner join DIM_MODEL As c
	On A.IDModel = C.IDModel
	group by A.IDModel,B.State,b.ZipCode,C.Model_Name

--Q3--END

--Q4--BEGIN.Show the cheapest cellphone (Output should contain the price also)
 select A.IDManufacturer,A.model_name,A.unit_price from DIM_MODEL as A
 where A.Unit_price = ( select MIN(unit_price) from  DIM_MODEL)


--Q4--END

--Q5--BEGIN. Find out the average price for each model in the top5 manufacturers in 
       --terms of sales quantity and order by average price. 
	   select DM.Manufacturer_name,PC.IDmodel, AVG(PC.totalPrice) as avg_revenue
	   from FACT_TRANSACTIONS as PC
	   inner join DIM_MODEL As PFO
	   On PC.IDModel = PFO.IDModel
	   inner join DIM_MANUFACTURER as DM
	   on DM.IDManufacturer = PFO.IDManufacturer 
	   where PFO.IDManufacturer IN
	   (
	   Select top 5 PFO.IDManufacturer from FACT_TRANSACTIONS as PC
	   inner join DIM_MODEL As PFO
	   On PFO.IDModel = PC.IDModel
	   group by PFO.IDManufacturer
	   order by SUM(PC.TotalPrice) DESC
	   )
	   group by DM.manufacturer_name , PC.IDModel
	   order by avg_revenue


--Q5--END

--Q6--BEGIN. List the names of the customers and the average amount spent in 2009, 
------where the average is higher than 500 
select A.IDCustomer , A.customer_name,ROUND(Avg(B.Totalprice),2) as avg_amount_spent 
from DIM_CUSTOMER as A
inner join FACT_TRANSACTIONS as B
ON A.IDCustomer = B.IDCustomer
where YEAR(B.date) = 2009
group by A.IDCustomer, A.Customer_Name
having round(avg(B.TotalPrice),2)>500

--Q6--END
	
--Q7--BEGIN  List if there is any model that was in the top 5 in terms of quantity, 
-----simultaneously in 2008, 2009 and 2010 
select T1.IDModel from
(select top 5 A.IDModel, SUM(A.Quantity) AS Model_Quantity from FACT_TRANSACTIONS as A
Where YEAR(A.date) = 2008
group by A. IDModel
Order by Model_Quantity DESC) as T1
 INTERSECT 
 select T2.IDModel From(
 Select top 5 A.IdModel, SUM(A.Quantity) as Model_Quantity
	from FACT_TRANSACTIONS as A 
	where Year (A.Date) = 2009 
	group by A.IDModel 
	order by Model_Quantity DESC) as T2
INTERSECT
	 select T3.IDModel From(
 Select top 5 A.IdModel, SUM(A.Quantity) as Model_Quantity
	from FACT_TRANSACTIONS as A 
	where Year (A.Date) = '2010' 
	group by A.IDModel 
	order by Model_Quantity DESC) as T3

--Q7--END	
--Q8--BEGIN.. Show the manufacturer with the 2nd top sales in the year of 2009 and the 
----manufacturer with the 2nd top sales in the year of 2010. 
select * from (select top 1* from ( Select top 2 B.IDManufacturer, SUM(A.totalPrice) as sales from FACT_TRANSACTIONS as A
inner join DIM_MODEL as B 
on A.IDModel = B.IDModel
where YEAR (A.Date) = 2009
group by b.IDManufacturer 
order by sales DESC ) as t1
order by t1.sales) as t11
union All
select* from (
select top 1 *from (  Select top 2 B.IDManufacturer, SUM(A.totalPrice) as sales from FACT_TRANSACTIONS as A
inner join DIM_MODEL as B 
on A.IDModel = B.IDModel
where YEAR (A.Date) = 2010
group by B.IDManufacturer
order by sales DESC)AS T2
order by T2.sales) as T22

--Q8--END
--Q9--BEGIN..Show the manufacturers that sold cellphones in 2010 but did not in 2009.
select * from
   (select B.IdManufacturer, C.Manufacturer_name from FACT_TRANSACTIONS as A
	inner join DIM_MODEL as B
	on A.IDModel = B.IDModel
	inner join DIM_MANUFACTURER as C
    On C.IDManufacturer = B.IDManufacturer
	where YEAR(A.date) = 2010
	group by B.IDManufacturer,C.Manufacturer_Name) as T1

Except
select * from
   (select B.IdManufacturer, C.Manufacturer_name from FACT_TRANSACTIONS as A
	inner join DIM_MODEL as B
	on A.IDModel = B.IDModel
	inner join DIM_MANUFACTURER as C
    On C.IDManufacturer = B.IDManufacturer
	where YEAR(A.date) = 2009
	group by B.IDManufacturer,C.Manufacturer_Name) as T2

--Q9--END

--Q10--BEGIN..Find top 100 customers and their average spend, average quantity by each 
----year. Also find the percentage of change in their spend.
	Select IDCustomer , YEAR, AVG_QTY, AVG_spent,
	((AVG_spent-previous_Avg_spent)/previous_avg_spent)*100 as perc_change
	from 
	   (Select IDcustomer, Year(date) as year,
	   AVG(totalprice) as avg_spent, AVG(Quantity) as AVG_QTY,
	   Lag(avg(totalPrice)) over( partition By IDCustomer order by year(date)) as previous_avg_spent
	   from Fact_transactions
	   where IDcustomer IN
	   (select T.IDCustomer from
	           (Select top 100 Idcustomer, YEAR(date) as year, SUM(Quantity) as Total_QTY, SUM(totalPrice) as Total_price
			   from FACT_TRANSACTIONS
			   group by IDCustomer,YEAR(date)
			   order by sum(totalprice) DESC) as T
			   )
			   group by IDCustomer, Year(date)) as TBL

--Q10--END
	